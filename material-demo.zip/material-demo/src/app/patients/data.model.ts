export interface ChatMessage {
    message: string,
    senderName: string,
    time: Date,
    isMine: boolean
}
