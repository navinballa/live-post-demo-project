import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { ChatMessage } from '../data.model';

@Component({
  selector: 'app-visit-history',
  templateUrl: './visit-history.component.html',
  styleUrls: ['./visit-history.component.css'],
})
export class VisitHistoryComponent implements OnInit {
  listOfChatMessages: ChatMessage[] = [
    {
      message: 'Hi',
      senderName: 'Navin',
      time: new Date(),
      isMine: true,
    },
    {
      message: 'Hellp',
      senderName: 'Anji',
      time: new Date(),
      isMine: false,
    },
  ];

  constructor(private spinner: NgxSpinnerService) {}

  ngOnInit(): void {
    this.spinner.show();
    setTimeout(() => {
      this.spinner.hide();
    }, 2000);
  }

  onSave() {
    localStorage.setItem("Token", "DUMMY_TOKEN")
  }

  onFetch() {
    alert(localStorage.getItem("Token"))
  }
}
