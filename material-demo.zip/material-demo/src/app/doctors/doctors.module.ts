import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppoinmentsComponent } from './appoinments/appoinments.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: "",
    redirectTo: "my-profile",
  },
  {
    path: "appointments",
    component: AppoinmentsComponent
  },
  {
    path: "my-profile",
    component: MyProfileComponent
  }
]

@NgModule({
  declarations: [
    AppoinmentsComponent,
    MyProfileComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class DoctorsModule { }
