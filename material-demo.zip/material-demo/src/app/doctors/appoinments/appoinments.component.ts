import { Component, OnInit } from '@angular/core';

interface Appointment {
  id: number,
  doctorName: string,
  patientName: string
}


@Component({
  selector: 'app-appoinments',
  templateUrl: './appoinments.component.html',
  styleUrls: ['./appoinments.component.css']
})
export class AppoinmentsComponent implements OnInit {
  listOfApp: Appointment[] = [
    {
      id: 1,
      doctorName: "Anji",
      patientName: "Navin"
    },
    {
      id: 2,
      doctorName: "Shweta",
      patientName: "Navin Balla"
    }
  ]

  pdfReport() {
    console.log("Hi");
    
  }

  constructor() { }

  ngOnInit(): void {
  }

}
