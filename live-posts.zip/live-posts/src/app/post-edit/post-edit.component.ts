import { Component, OnInit } from '@angular/core';
import {
  AbstractControl,
  FormControl,
  FormGroup,
  ValidationErrors,
  ValidatorFn,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Post } from '../models/post.model';
import { PostService } from '../services/post.service';
import { titleValidator, postValidator } from './validators';

@Component({
  selector: 'app-post-edit',
  templateUrl: './post-edit.component.html',
  styleUrls: ['./post-edit.component.css'],
})
export class PostEditComponent implements OnInit {
  form: FormGroup = new FormGroup({});
  post!: Post;
  index: number = -1;

  constructor(
    public postService: PostService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    // trying to read index
    this.route.params.subscribe((params) => {
      if (params['index']) {
        this.index = +params['index'];

        if (this.index !== -1) {
          this.post = this.postService.getPostByIndex(this.index);
        }
      }
    });

    // Form initialization
    this.form = new FormGroup(
      {
        title: new FormControl(this.post?.title ? this.post.title : null, []),
        description: new FormControl(
          this.post?.description ? this.post.description : null,
          []
        ),
        imagePath: new FormControl(
          this.post?.imagePath ? this.post.imagePath : null,
          []
        ),
      },
      [postValidator()]
    );
  }

  onSubmit() {
    console.log(this.form);

    let title = this.form.value.title;
    let description = this.form.value.description;
    let imagePath = this.form.value.imagePath;

    let ob: Post = new Post(
      title,
      description,
      imagePath,
      'test@test.com',
      new Date()
    );

    console.log(this.index);

    // post update
    if (this.index === -1) {
      this.postService.addPost(ob);
      console.log('Hi');
    } else {
      this.postService.updatePost(this.index, ob);
    }
    // Nabvigation
    this.router.navigate(['/post-list']);
  }

  onClear() {
    this.form.reset();
  }
}
