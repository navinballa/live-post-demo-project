import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css'],
})
export class AuthComponent implements OnInit {
  form: FormGroup = new FormGroup({});

  constructor(private authService: AuthService, private router: Router) {
    console.log("I am constrcutor");
    //
  }

  ngOnInit(): void {
    console.log("In am ngOnInit");
    
    // Foprm Intitialization
    this.form = new FormGroup({
      email: new FormControl(null, [Validators.required, Validators.email]),
      password: new FormControl(null, [Validators.required, Validators.minLength(4)]),
    });
  }

  ngOnDestroy() {
    console.log("I am ngOnDestroy()");
    
  }

  onLogin() {
    let email:string = this.form.value.email;
    let password:string = this.form.value.password;

    let result = this.authService.login(email, password)   

    if (result === true) {
      // navigate to post-list
      this.router.navigate(["/post-list"])
    } else {
      alert("Loged failed, try again!")
    }
    

  }

  onSignup() {
    console.log('Hi I am signup fun()');
  }
}
