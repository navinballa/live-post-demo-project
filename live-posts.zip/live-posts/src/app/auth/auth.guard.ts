import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  RouterStateSnapshot,
  UrlTree,
} from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../services/auth.service';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
  loggedInEmail: string | null = '';

  constructor(private authService: AuthService) {
    authService.userInfo.subscribe((email) => {
      if (email === '') {
        this.loggedInEmail = null;
      } else {
        this.loggedInEmail = email;
      }
    });
  }

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ):
     boolean
    | UrlTree
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree> {
    console.log('I am Auth Route Guard');

    return this.loggedInEmail ? true : false;
  }
}
