import { HttpClient } from '@angular/common/http';
import { analyzeAndValidateNgModules } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { Post } from '../models/post.model';

@Injectable({ providedIn: 'root' })
export class PostService {
  constructor(private http: HttpClient) {}

  private listOfPosts: Post[] = [];
  // new Post(
  //   'Nature 2',
  //   'Nature is a British weekly scientific journal founded and based in London, England. As a multidisciplinary publication, Nature features peer-reviewed research from a variety of academic disciplines, mainly in science and technology.',
  //   'https://d1whtlypfis84e.cloudfront.net/guides/wp-content/uploads/2019/07/23090714/nature-1024x682.jpeg',
  //   'test@test.com',
  //   new Date()
  // ),
  // new Post(
  //   'Araku Valley',
  //   `Araku Valley is a hill station and valley region in the southeastern Indian state of Andhra Pradesh. It's surrounded by the thick forests of the Eastern Ghats mountain range. The Tribal Museum is dedicated to the area's numerous indigenous tribes, known for their traditional Dhimsa dance, and showcases traditional handicrafts.`,
  //   'https://vizagtourism.org.in/images/places-to-visit/header/araku-valley-vizag-tourism-entry-fee-timings-holidays-reviews-header.jpg',
  //   'test@test.com',
  //   new Date()
  // ),
  // new Post(
  //   'Cricket',
  //   'IPL',
  //   'https://d1e00ek4ebabms.cloudfront.net/production/a646c9b7-13a5-4420-ab42-13ac0cf8a158.jpg',
  //   'test@test.com',
  //   new Date()
  // ),
  // new Post(
  //   'Hapmi',
  //   'Nice place',
  //   'https://www.karnatakatourism.org/wp-content/uploads/2020/05/Hampi.jpg',
  //   'test@test.com',
  //   new Date()
  // ),
  //];

  getAllPosts() {
    return this.listOfPosts;
  }

  addPost(post: Post) {
    // this.listOfPosts.push(post);
    this.http.post('http://localhost:3000/posts', post).subscribe((res) => {
      console.log(res);
      this.fetchFromBackend();
    });
  }

  getPostByIndex(index: number): Post {
    return this.listOfPosts[index];
  }

  updatePost(index: number, updatedPost: Post) {
    this.listOfPosts[index] = updatedPost;
  }

  deletePost(id: number | undefined) {
    // this.listOfPosts.splice(index, 1);

    this.http.delete('http://localhost:3000/posts/' + id).subscribe((res) => {
      console.log(res);
      this.fetchFromBackend()
    });
  }

  fetchFromBackend() {
    this.http
      .get<Post[]>('http://localhost:3000/posts')
      .subscribe((res: Post[]) => {
        // Deleting onject inside the array
        this.listOfPosts.splice(0, this.listOfPosts.length);

        // Pushing objects
        this.listOfPosts.push(...res);

        // this.listOfPosts.push(res[0])
        // this.listOfPosts.push(res[1])
        // this.listOfPosts.push(res[2])
      });
  }
}
