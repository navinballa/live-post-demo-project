import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { PostService } from '../services/post.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  loggedInEmail: string | null = null;

  constructor(
    private postService: PostService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.authService.userInfo.subscribe((email: string) => {
      if (email === '') {
        this.loggedInEmail = null;
      } else {
        this.loggedInEmail = email;
      }
    });
  }

  fetchData() {
    this.postService.fetchFromBackend();
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/auth'])
    console.log("Hi");
    
  }
}
